import { DishaDirectApp } from "@/components/disha-direct-app";

export default function Home() {
  return (
    <DishaDirectApp />
  );
}
