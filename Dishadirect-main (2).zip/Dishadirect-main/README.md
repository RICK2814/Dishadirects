<<<<<<< HEAD
# Dishadirect
Dishadirect is an AI-powered career guidance platform that creates personalized roadmaps based on each student’s strengths and interests. It bridges skill gaps with actionable steps, offers 24/7 mentorship via an AI chatbot, and prepares students for emerging roles. Mobile-first and scalable, it makes career counseling accessible across India.
=======
# Firebase Studio

This is a NextJS starter in Firebase Studio.

To get started, take a look at src/app/page.tsx.
>>>>>>> 7cb168a (Initialized workspace with Firebase Studio)
